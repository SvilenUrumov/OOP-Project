package Functions;

public class Erase {
}

package Functions;

public class Translate {
}

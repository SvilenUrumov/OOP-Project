package Commands;

public class Exit {
}
